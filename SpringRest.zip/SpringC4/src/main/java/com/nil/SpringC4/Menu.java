package com.nil.SpringC4;

public class Menu {
	
	public static int displayMenu() {
		// TODO Auto-generated method stub
		return 0;
	}


}
